#!/usr/bin/env python3
score = int(input(""))

if score < 0 or score > 100:
    print("error")
else:
    if score >=71 and score <=100:
        print("high pass")
    elif score >= 31 and score <=70:
        print("low pass")
    else:
        print("fail")
