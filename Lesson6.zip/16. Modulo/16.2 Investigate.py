# Example Code

num1 = int(input("Enter a number"))

print ("I will now calculate if your number is in the two times table.")

remainder = num1 % 2

if remainder == 0:
  print("Your number is in the two times table")
else:
  print("Your number is not in the two times table")

# What is the purpose of the code?
  # Answer 

# What symbol is used for modulus?
  # Answer 

# What would happen if the input to the program was 17?
  # Answer

# What would happen if the input to the program was 98?
  # Answer

# What is the condition in the code?
  # Answer

# Why can the code use 'else' instead of 'elif' and still work correctly?
  # Answer