8 % 3
9 % 3
14 % 5

remainder = 10 % 4
print(remainder)

num1 = 16
num2 = 4

remainder = num1 % num2
print("The remainder is " + str(remainder))