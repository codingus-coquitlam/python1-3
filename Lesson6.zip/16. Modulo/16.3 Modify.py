# Starter Code

name = input("enter your name!")

nameLength = len(name)
nameRemainder = nameLength % 2

if nameRemainder == 0:
    print("your name has even number of characters")
else:
    print("your name has odd number of characters")