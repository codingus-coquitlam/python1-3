num1 = 9

num1 < 5 and num1 < 10
num1 < 10 and num1 < 20

num1 < 5 or num1 < 10
num1 < 10 or num1 < 20

not(num1 > 10)
not(num1 == 9)
not(num1 != 9)


name = "Dave"
homeTown = "Seattle"
hair = "black"

if name == "Dave" and homeTown == "Seattle":
  print("Hi there Dave from Seattle!")
else:
  print("You're not Dave from Seattle!")

if name == "Dave" or homeTown == "Seattle":
  print("You're either called Dave or you're from Seattle!")
else:
  print("You're not Dave, and you aren't from Seattle!")