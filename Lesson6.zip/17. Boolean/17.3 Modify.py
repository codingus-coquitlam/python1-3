#!/usr/bin/env python3

# Starter Code

name = input("enter a name\n")
homeTown = input("enter your hometown\n").upper()

if name.upper() == "DAVE" and homeTown == "SEATTLE":
  print("Hi there Dave from Seattle!")
elif name == "DAVE" or homeTown == "SEATTLE":
  print("You're either called Dave or you're from Seattle!")
else:
  print("You're not Dave, and you aren't from Seattle!")