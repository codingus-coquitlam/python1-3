print("Enter a number between 50 and 100")
num1 = int(input())

while num1 < 50 or num1 > 100:

  if num1 < 50:
    print("Invalid number, too small, try again.")
   
  num1 = int(input())