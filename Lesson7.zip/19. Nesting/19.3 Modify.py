name = 
homeTown = 

if name == "Dave" and homeTown =="Seattle":
    occupation = 
    if occupation == :

    else:

