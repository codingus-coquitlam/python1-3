# Example Code

num1 = 45

if num1 > 20:
  print("Bigger than 20")

  if num1 > 50:
    print(" and bigger than 50")
  else:
    print("but not bigger than 50")

else:
  print("Smaller than 20")