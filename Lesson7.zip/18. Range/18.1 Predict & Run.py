print("Enter the number of the month in which you were born.")
birthMonth = int(input())

if birthMonth >= 1 and birthMonth <=12:
  print("Thanks")
else:
  print("That's not a month!")