"Hello World".upper()

print("Hello World!".lower())

word = "Apricot"

wordUpper = word.upper()

print(wordUpper)

print(word.lower())