# Example Code

import random

print("Welcome to the dice simulator!")

num1 = random.randint(1,6)

print("You rolled a " + str(num1))


# What is the term for the (1,6) values used by the randint function?
  # Answer 

# Why are the numbers in brackets not (0,6)
  # Answer

# What would the effect be if the last two lines of code swapped places?
  # Answer

# What is the purpose of this program?
  # Answer