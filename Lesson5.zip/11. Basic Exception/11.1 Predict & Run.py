def HelloWorld():
  print("Hello World")

def Greeting1():
  name = "Dave"
  print("Hello " + name)

def Greeting2(name):
  print("Hello " + name)

def ErrorMessage():
  print("There has been an error")

try:
  HelloWorld()
except:
  ErrorMessage()

try:
  Greeting1()
except:
  ErrorMessage()

try:
  Greeting2(name)
except:
  ErrorMessage()
