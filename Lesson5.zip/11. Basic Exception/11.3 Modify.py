# Starter Code

try:
  print(x)
except:
  print("")