# Starter Code

rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

listLength = len(rockStars)

print(rockStars[3:listLength])