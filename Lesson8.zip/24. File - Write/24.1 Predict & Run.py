def WriteToFile():
  myFile = open("24. File - Write/Writing.txt","w") 
  myFile.write("Bob")
  myFile.close()

def AppendToFile(name):
  myFile = open("24. File - Write/Appending.txt","a") 
  myFile.write(name + "\n")
  myFile.close()

WriteToFile()

name = "Dave"
AppendToFile(name)

name = "Freddie"
AppendToFile(name)
