# Task Make
# Write a program that outputs a joke on multiple lines. 
