# Starter Code

videoGames = ["Mario", "Sonic", "Joust", "Zelda"]