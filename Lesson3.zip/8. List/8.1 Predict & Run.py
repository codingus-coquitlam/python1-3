# Example Code 1

Sentence = ["Always", "look", "on", "the", "bright", "side", "of",]
print(Sentence)
print(Sentence[1])
Sentence.append("life")
Sentence[4] = "sunny"
print(Sentence[4])
print(Sentence[0] + " " + Sentence[3])
print(Sentence)