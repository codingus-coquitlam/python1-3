# Example Code

def maths1():
  num1 = 50
  num2 = 5
  return num1 + num2

def maths2():
  num1 = 50
  num2 = 5
  return num1 - num2

def maths3(num1, num2):
  return num1 * num2

outputNum = maths2()
print(outputNum)

# How many functions are there in the code?
  # Answer

# How do you know that they are functions, not just subroutines?
  # Answer

# Which functions have parameters?  How can you tell?
  # Answer

# Which functions are called in the code?
  # Answer

# How do you know which lines of code belong to a function or subroutine?
  # Answer