# Example Code 1

def say_hi():
  print("Why hello there!")

def offer_drink():
  print("Would you care for a spot of tea?")

def offer_food():
  print("Biscuit?")

def say_bye():
  print("Cheerio then.")


offer_drink()
say_hi()
offer_food()

# Example code 2
def maths1():
  num1 = 50
  num2 = 5
  return num1 + num2

def maths2():
  num1 = 50
  num2 = 5
  return num1 - num2

def maths3():
  num1 = 50
  num2 = 5
  return num1 * num2

outputNum = maths3()
print(outputNum)

# Example Code 3
def location(country):
  print("I am from " + country)


location("Brazil")

