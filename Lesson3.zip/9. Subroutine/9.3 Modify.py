def my_function(country):
  print("I am from " + country)


my_function("Brazil")
