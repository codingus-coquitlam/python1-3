number = 6
counter = 1

while counter < 13:
  print(counter * number)
  counter = counter + 1  