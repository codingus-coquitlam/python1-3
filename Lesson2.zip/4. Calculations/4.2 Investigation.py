# Starter code

num1 = 25
num2 = 4
print("Enter a number")
num3 = int(input())

total1 = num1 // num2 
total2 = num3 + num2
total3 = total1 - total2

# How many variables are used in the code?
  # Answer 

# Give the line number where an output statement is used.
  # Answer 

# What symbol is used for variable assignment?
  # Answer =

# What value is stored in total1 at the end of the program?
  # Answer 

# What value is stored in num3 at the end of the program?
  # Answer 

# Line 8 is changed to total1 = num1 // num2. How would it affect the program?
  # Answer