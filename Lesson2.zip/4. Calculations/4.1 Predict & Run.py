# Add comments to this code to predict what it will do.
print(8 + 2)

print( 8 - 2)

print(8 * 2)

print(10 / 4)

print(10 // 4)

# This code uses variables in place of numbers in the calculation.  Add comments to explain how it works.

num1 = 20
num2 = 5

result = num1 * num2

print(result)

# This code uses input to assign data into a variable.  Add comments to explain how it works.
print("Enter a number")
num1 = int(input())
num2 = 2

result = num1 // num2

print(result)