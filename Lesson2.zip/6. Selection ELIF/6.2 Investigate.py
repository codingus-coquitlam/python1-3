# Example Code

number1 = int(input("Please enter a number"))
number2 = int(input("Please enter another number"))

if number1 > number2:
  print("Number 1 is bigger than number 2")
elif number2 > number1: 
  print("Number 2 is bigger than number 1")
else:
  print("Both numbers are the same")


# What line does selection start on?
  # Answer

# How many selection statements are there in the code?
  # Answer

# How many conditions are there in the code?
  # Answer

# What does the > operator mean?
  # Answer

# Why are lines7, 9 and 11 indented?
  # Answer

# What is the purpose of this program?
  # Answer