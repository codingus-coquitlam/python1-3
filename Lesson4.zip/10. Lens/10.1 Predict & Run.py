# Example Code

wordLength = len("Hello World!")

print(wordLength)

word = "I love strings!"

wordLength = len(word)

print(wordLength)