# Example code

sName = "Smith"
nameLength = len(sName)
print(nameLength)

# How many variables are used in the code?
  # Answer


# What is the purpose of the = symbol on line 4?
  # Answer

# Explain what the len() command on line 4 does.
  # Answer

# Line 5 is changed to print(sName). How will this affect the way the code runs?
  # Answer