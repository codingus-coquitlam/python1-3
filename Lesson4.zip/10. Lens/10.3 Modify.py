# Starter Code

print("Enter your first name")
input() 


fNameLength = 

if fNameLength > 10:
  print("What a long name!")
else:
  print("What a lovely name")
