

name = "Elizabeth"

input("Enter a number")

letter = 

print()