phrase1 = "I love Computer Science"
phrase2 = "Python is awesome"

print("Read Only Memory"[6])
print(phrase1[2]) 
print(phrase2[12])

# What is the key term for the number used to denote the position of a character in a string?
  # Answer 

# Line 5 is changed to print(phrase2[2]).  How will this affect the way the program runs?
  # Answer

# What could you use in the square brackets instead of a number?
 # Answer

