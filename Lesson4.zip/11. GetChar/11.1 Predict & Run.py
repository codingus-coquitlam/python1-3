# Example Code

phrase1 = "I love Computer Science"
phrase2 = "Python is awesome"

print("Read Only Memory"[6])
print(phrase1[2])
print(phrase2[12])