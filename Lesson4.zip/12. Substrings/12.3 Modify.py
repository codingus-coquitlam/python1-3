#Starter Code

phrase = "I love computer science"

print("enter a number between 0 and " +)
num2 = input()

print(phrase[0:])