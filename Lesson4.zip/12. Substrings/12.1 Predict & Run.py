# Starter Code

phrase1 = "Zoe saw a zebra "
phrase2 = "at the zoo"

print(phrase1[1:4])

print(phrase1[11:15])

newPhrase = phrase1 + phrase2

print(newPhrase[10:20])
