phrase1 = "Zoe saw a zebra "
phrase2 = "at the zoo"

print(phrase1[1:4])

print(phrase1[11:15])

newPhrase = phrase1 + phrase2

print(newPhrase[10:20])

# What is the purpose of the '+' on line 8?
  # Answer

# How do you recognise a substring in code?
  # Answer

# Line 4 is changed to 'print(phrase1[0:3]'.  How does this affect the way the program runs?
  # Answer

# Line 8 is changed to 'newPhrase = phrase2 + phrase1'.  How does this affect the way the program runs?
  # Answer